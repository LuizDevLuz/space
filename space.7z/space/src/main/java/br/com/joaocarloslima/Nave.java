package br.com.joaocarloslima;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Nave extends Asset {
    public enum Direcao {
        ESQUERDA, DIREITA;
    }

    private Direcao direcao;

    public Nave(double x, double y, ImageView imagem) {
        super(x, y, 0, imagem);
        this.direcao = Direcao.DIREITA; // Direção padrão
    }

    public Tiro atirar(int poder) {
        ImageView tiroImagem = new ImageView(new Image("file:src/main/resources/br/com/joaocarloslima/images/laser.png"));
        Tiro tiro = new Tiro(this.x, this.y, poder, tiroImagem);
        tiroImagem.setRotate(270); // Direção para cima
        return tiro;
    }

    @Override
    public void mover() {
        // Implementação do movimento da nave
        if (this.direcao == Direcao.ESQUERDA) {
            this.x -= this.velocidade;
        } else if (this.direcao == Direcao.DIREITA) {
            this.x += this.velocidade;
        }

        if (this.x < 0) this.x = 0;
        if (this.x > 640 - 50) this.x = 640 - 50;
    }

    public void setDirecao(Direcao direcao) {
        this.direcao = direcao;
    }
}
