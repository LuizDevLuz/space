package br.com.joaocarloslima;

import java.util.ArrayList;
import java.util.List;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Jogo {
    private List<Asset> assets = new ArrayList<>();
    private Nave nave;
    private int pontos = 0;
    private int nivel = 1;

    public Jogo(Nave nave) {
        this.nave = nave;
    }

    public Tiro atirar() {
        Tiro tiro = nave.atirar(1);
        assets.add(tiro);
        return tiro;
    }

    public Meteoro criarMeteoro() {
        Meteoro meteoro = new Meteoro(Math.random() * 640, 0, new ImageView(new Image("file:src/main/resources/br/com/joaocarloslima/images/meteoro.png")));
        assets.add(meteoro);
        return meteoro;
    }

    public void pontuar() {
        pontos++;
        if (pontos % 10 == 0 && nivel < 4) {
            nivel++;
        }
    }

    public int getPontos() {
        return pontos;
    }

    public int getNivel() {
        return nivel;
    }

    public List<Asset> getAssets() {
        return assets;
    }

    public Nave getNave() {
        return nave;
    }
}
