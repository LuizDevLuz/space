package br.com.joaocarloslima;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Meteoro extends Asset {
    private int tamanho;

    public Meteoro(double x, double y, ImageView imagem) {
        super(x, y, 5, imagem);
        this.tamanho = (int) (Math.random() * 8) + 1;
        // Definir a imagem de acordo com o tamanho
        this.imagem.setImage(new Image("path/to/meteoro" + this.tamanho + ".png"));
    }

    public void tomarTiro(Tiro tiro) {
        this.tamanho -= tiro.getPoder();
    }

    public int getPoder() {
        return tamanho;
    }
}
