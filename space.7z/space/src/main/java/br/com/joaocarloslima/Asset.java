package br.com.joaocarloslima;

import javafx.scene.image.ImageView;

public abstract class Asset {
    protected double x, y, velocidade;
    protected ImageView imagem;

    public Asset(double x, double y, double velocidade, ImageView imagem) {
        this.x = x;
        this.y = y;
        this.velocidade = velocidade;
        this.imagem = imagem;
    }

    public void mover() {
        // Atualiza a posição do objeto com base na velocidade e na direção
        this.x += this.velocidade * Math.cos(Math.toRadians(this.imagem.getRotate()));
        this.y += this.velocidade * Math.sin(Math.toRadians(this.imagem.getRotate()));
        this.imagem.setLayoutX(this.x);
        this.imagem.setLayoutY(this.y);
    }

    public boolean colidiuCom(Asset outro) {
        return this.imagem.getBoundsInParent().intersects(outro.getImagem().getBoundsInParent());
    }

    public ImageView getImagem() {
        return imagem;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
