package br.com.joaocarloslima;

import javafx.scene.image.ImageView;

public class Tiro extends Asset {
    private int poder;

    public Tiro(double x, double y, int poder, ImageView imagem) {
        super(x, y, 10, imagem);
        this.poder = poder;
    }

    public int getPoder() {
        return poder;
    }
}
